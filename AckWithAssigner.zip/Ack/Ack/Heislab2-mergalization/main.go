package main

import (
	"Network-go/network/assigner"
	"Network-go/network/bcast"
	"Network-go/network/config"
	"Network-go/network/elevator"
	"Network-go/network/elevio"
	"Network-go/network/fsm"
	"Network-go/network/localip"
	"Network-go/network/master"
	"Network-go/network/peers"
	"Network-go/network/timer"
	"flag"
	"fmt"
	"os"
	"time"
)

// We define some custom struct to send over the network.
// Note that all members we want to transmit must be public. Any private members
//
//	will be received as zero-values.
type HelloMsg struct {
	Message string
	Iter    int
}

type MasterMsg struct {
	Message  string
	MasterID string
}

type requestMsg struct {
	Floor   int
	Button  elevio.ButtonType
	OrderID string
}

type ackMsg struct {
	OrderID string
}

type ButtonMsg struct {
	Message elevator.Elevator
	ID      string
}

var (
	ackchan    = 16572
	orderchan  = 16571
	peerchan   = 64715
	hellochan  = 61569
	masterchan = 21708
	statechan  = 26573
)

var pendingOrders = make(map[string]requestMsg)
var elevatorStates = make(map[string]elevator.Elevator)
var Masterid string
var network_connection bool

func main() {
	//From single elevator
	var id string
	flag.StringVar(&id, "id", "", "id of this peer")
	flag.Parse()
	elevio.Init("localhost:1729"+id, config.NumFloors)

	var (
		e                 elevator.Elevator
		prevRequestButton [config.NumFloors][config.NumButtons]bool
		prevFloorSensor   = -1
		obstruction       bool
	)

	//initializing elevator
	fmt.Printf("Elevator starting \n")
	elevator.InitializeElevator(&e, &prevRequestButton)

	drv_buttons := make(chan elevio.ButtonEvent)
	drv_floors := make(chan int)
	drv_obstr := make(chan bool)
	drv_stop := make(chan bool)

	go elevio.PollButtons(drv_buttons)
	go elevio.PollFloorSensor(drv_floors)
	go elevio.PollObstructionSwitch(drv_obstr)
	go elevio.PollStopButton(drv_stop)

	OrderTx := make(chan requestMsg)
	OrderRx := make(chan requestMsg)
	ackRx := make(chan ackMsg)
	ackTx := make(chan ackMsg)
	stateTx := make(chan ButtonMsg)
	stateRx := make(chan ButtonMsg)

	//From network

	// Our id can be anything. Here we pass it on the command line, using
	//  `go run main.go -id=our_id`

	// ... or alternatively, we can use the local IP address.
	// (But since we can run multiple programs on the same PC, we also append the
	//  process ID)
	if id == "" {
		localIP, err := localip.LocalIP()
		if err != nil {
			fmt.Println(err)
			localIP = "DISCONNECTED"
		}
		id = fmt.Sprintf("peer-%s-%d", localIP, os.Getpid())
	}

	peerUpdateCh := make(chan peers.PeerUpdate)
	peerTxEnable := make(chan bool)

	go peers.Transmitter(peerchan, id, peerTxEnable)
	go peers.Receiver(peerchan, peerUpdateCh)

	helloTx := make(chan HelloMsg)
	helloRx := make(chan HelloMsg)

	go bcast.Transmitter(hellochan, helloTx)
	go bcast.Receiver(hellochan, helloRx)

	MasterbcastTx := make(chan MasterMsg)
	MasterbcastRx := make(chan MasterMsg)
	go bcast.Receiver(masterchan, MasterbcastRx)

	go func() {
		helloMsg := HelloMsg{"Hello from " + id, 0}
		for {
			helloMsg.Iter++
			helloTx <- helloMsg
			time.Sleep(1 * time.Second)
		}
	}()

	// go func() {
	// 	for {
	// 		if sjekk {
	// 			break
	// 		}
	// 		MasterMsg := MasterMsg{"I am something", id}
	// 		MasterbcastTx <- MasterMsg
	// 		time.Sleep(1 * time.Second)
	// 	}
	// }()

	go bcast.Receiver(orderchan, OrderRx)
	go bcast.Transmitter(orderchan, OrderTx)
	go bcast.Transmitter(ackchan, ackTx)
	go bcast.Receiver(ackchan, ackRx)
	go bcast.Transmitter(statechan, stateTx)
	go bcast.Receiver(statechan, stateRx)

	go func() {
		for {
			stateTx <- ButtonMsg{Message: e, ID: id}
			time.Sleep(200 * time.Millisecond)
		}
	}()

	fmt.Println("Started")
	timeout := time.After(5 * time.Second)
	for {
		// If local elevator is dedicated master, starts broadcasting heartbeat. Network connection is not what it seems
		if Masterid == id && Masterid != "" && !network_connection {
			go bcast.Transmitter(masterchan, MasterbcastTx)
			network_connection = true
			go func() {
				MasterMsg := MasterMsg{"I am the master", Masterid}
				for {
					MasterbcastTx <- MasterMsg
					time.Sleep(1 * time.Second)
					if !network_connection {
						break
					}
				}
			}()
		}
		select {
		// Activates upon change in peers-struct
		case p := <-peerUpdateCh:
			var lostLelevator string = "99"
			fmt.Printf("Peer update:\n")
			fmt.Printf("  Peers:    %q\n", p.Peers)
			fmt.Printf("  New:      %q\n", p.New)
			fmt.Printf("  Lost:     %q\n", p.Lost)
			if len(p.Lost) > 0 {
				lostLelevator = p.Lost[0]
			}
			if lostLelevator == Masterid && len(p.Peers) > 0 {
				master.MasterElection(p.Peers, id, &Masterid)
			}
		// Activates upon recieved heartbeat from master
		case a := <-MasterbcastRx:
			Masterid = a.MasterID
			//fmt.Printf("Received: %#v\n", a) DENNE ER TATT UT
			timeout = time.After(2 * time.Second)

		// Activates if not recieved master heartbeat
		case <-timeout: // Timeout after 5 seconds
			if Masterid == id {
				//Ute av nettverket
				network_connection = false
				print("I'm out of the network \n")
			}
			Masterid = id
			fmt.Println("Timeout: No data received making myself master\n ")

		// Activates upon local elevator button press. Adds this to "Elevator" struct "e"
		case button := <-drv_buttons:
			e.Requests[button.Floor][button.Button] = true
			//elevio.SetButtonLamp(button.Button, button.Floor, true)
			//fsm.Fsm_onRequestButtonPress(&e, button.Floor, button.Button)

			if Masterid == id {
				e.Requests[button.Floor][button.Button] = true
				//send excec
				assigner.Assigner(elevatorStates["1"], elevatorStates["2"], elevatorStates["3"])
			} else {
				request := requestMsg{button.Floor, button.Button, id}
				OrderTx <- request
				pendingOrders[request.OrderID] = request
				fmt.Println("Added order to pendingOrders from:", request.OrderID)
			}

		// Activates upon local elevator floor arrival. Updates "Elevator" struct "e".
		case floor := <-drv_floors:
			if floor != -1 && floor != prevFloorSensor {
				fsm.Fsm_onFloorArrival(&e, floor)
			} else {
				prevFloorSensor = floor
			}

		// Starts door timer if not obstructed
		case <-timer.TimerChannel:
			if !obstruction {
				fsm.Fsm_onDoorTimeout(&e)
				obstruction = false
			} else {
				timer.StartTimer(config.ObstructionDurationS)
			}
		// Obstruction activated.
		case <-drv_obstr:
			if e.Behaviour == elevator.EB_DoorOpen {
				elevio.SetDoorOpenLamp(true)
				obstruction = !obstruction
			}

		// Stop button pressed.
		case stop := <-drv_stop:
			if stop {
				elevio.SetMotorDirection(elevio.MD_Stop)
				e.Behaviour = elevator.EB_Idle
			}
			time.Sleep(time.Duration(config.InputPollRate))

		case r := <-OrderRx: //r for request
			if Masterid == id {
				ack := ackMsg{OrderID: r.OrderID}
				ackTx <- ack
				fmt.Println("Sent ACK from :", ack.OrderID)
				//Send excec
				assigner.Assigner(elevatorStates["1"], elevatorStates["2"], elevatorStates["3"])
			}
		case ack := <-ackRx:
			delete(pendingOrders, ack.OrderID)
			fmt.Println("Received ACK from:", ack.OrderID)

		case <-time.After(300 * time.Millisecond):
			for _, request := range pendingOrders {
				OrderTx <- request
			}
		case state := <-stateRx:
			elevatorStates[state.ID] = state.Message

		}
	}
}
