package main

import (
	"fmt"
	"log"
	"os"
	"os/exec"
	"strconv"
	"syscall"
	"time"
	//"transmit/UDP"
)

var backup_inc bool

func main() {
	print("\n--- Backup phase ---\n")
	file, err := os.Open("data.txt")
	if err != nil {
		log.Fatal(err)
	}
	defer func() {
		if err = file.Close(); err != nil {
			log.Fatal(err)
		}
	}()

	// --- Creating backup terminal, if backup doesn't exist ---
	for {
		backupChecking()
		if backup_inc {
			backupCreation()
			fmt.Printf(".. timed out\n")
			backup_inc = false
			fmt.Printf("\n-- Primary phase --\n")
			counter()
		}
	}
}

func counter() {

	num, err := os.ReadFile("data.txt")
	if err != nil {
		log.Fatal(err)
	}
	str := string(num)
	counter, err1 := strconv.Atoi(str)
	if err1 != nil {
		log.Fatal(err1)
	}
	currData := counter
	for i := currData; i < currData+5; i++ {
		fmt.Printf(": %v\n", i)
		err := os.WriteFile("data.txt", []byte(strconv.Itoa(i)), 0666)

		if err != nil {
			log.Fatal(err)
		}
		time.Sleep(2 * time.Second)
	}
	// fmt.Printf("Counting finished\n")
	pid := os.Getpid()
	syscall.Kill(pid, syscall.SIGTERM)
}

func backupCreation() {
	cmd := exec.Command("gnome-terminal", "--", "go", "run", "main.go")
	err := cmd.Run()
	if err != nil {
		fmt.Printf("Fatal error\n")
	}

}

func backupChecking() {
	for {
		// ---------------------
		data, err := os.ReadFile("../mandag_10_2/data.txt")
		if err != nil {
			log.Fatal(err)
		}
		prev := string(data)
		time.Sleep(2 * time.Second)
		data, err = os.ReadFile("../mandag_10_2/data.txt")
		if err != nil {
			log.Fatal(err)
		}
		curr := string(data)
		// ---------------------

		if curr == prev {
			print("Master stopped updating\n")
			backup_inc = true
			break
		}
		fmt.Println("data: " + string(data))
	}
}
