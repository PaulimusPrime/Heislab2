# Project

Every module contains a seperate README which contains information about the module. The multiple elevator system is designed according to the TTK4145 project description.

## Our approach

The system is finite state machine (FSM) based, with supporting modules which contain the separated systems of the working program. 