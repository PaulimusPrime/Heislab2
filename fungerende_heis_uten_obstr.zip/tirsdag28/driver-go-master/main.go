package main

import (
	// "Driver-go/config"
	"Driver-go/config"
	"Driver-go/elevator"
	"Driver-go/elevio"
	"Driver-go/fsm"
	"Driver-go/timer"
	"fmt"

	//"Driver-go/requests"
	//"Driver-go/timer"
	//"fmt"
	"time"
)

func main() {

	elevio.Init("localhost:15657", config.NumFloors)

	var (
		e                 elevator.Elevator
		prevRequestButton [config.NumFloors][config.NumButtons]bool
		prevFloorSensor   = -1
		obstruction		  bool
	)
	
	//initializing elevator hopefully correctly
	fmt.Printf("Elevator starting \n")
	e.Behaviour = elevator.EB_Idle
	e.Floor = elevio.GetFloor()
	e.Dirn = elevio.MD_Stop
	for f := 0; f < config.NumFloors; f++ {
		for b := 0; b < config.NumButtons; b++ {
			e.Requests[f][b] = false
			prevRequestButton[f][b] = false
			elevio.SetButtonLamp(elevio.ButtonType(b), f, false)
			elevio.SetDoorOpenLamp(false)
		}

	}

	//For loop to always start in first floor
	for {
		e.Floor = elevio.GetFloor()
		if e.Floor != 0 {
			elevio.SetMotorDirection(elevio.MD_Down)
			time.Sleep(time.Duration(config.InputPollRate))
		} else {
			elevio.SetMotorDirection(elevio.MD_Stop)
			break
		}
	}

	drv_buttons := make(chan elevio.ButtonEvent)
	drv_floors := make(chan int)
	drv_obstr := make(chan bool)
	drv_stop := make(chan bool)
	drv_timer := make(chan bool)
	

	go elevio.PollButtons(drv_buttons)
	go elevio.PollFloorSensor(drv_floors)
	go elevio.PollObstructionSwitch(drv_obstr)
	go elevio.PollStopButton(drv_stop)
	go timer.Timer(drv_timer, obstruction)


	for {
		fmt.Printf("----------------BEGIN\n")
		select {
		case button := <-drv_buttons:
			e.Requests[button.Floor][button.Button] = true
			elevio.SetButtonLamp(button.Button, button.Floor, true)
			for f := 0; f < config.NumFloors; f++ {
				for b := 0; b < config.NumButtons; b++ {
					v := e.Requests[f][b]
					if v && v != prevRequestButton[f][b] {
						e = fsm.Fsm_onRequestButtonPress(e, f, elevio.ButtonType(b))
					}
					prevRequestButton[f][b] = v
				}
			}

		case floor := <-drv_floors:
			if floor != -1 && floor != prevFloorSensor {
				e = fsm.Fsm_onFloorArrival(e, floor)
			} else {
				prevFloorSensor = floor
			}

		
		case <-drv_timer:
			time.Sleep(config.DoorOpenDurationS)
			e = fsm.Fsm_onDoorTimeout(e)
		case obstruction := <- drv_obstr:
			if obstruction && e.Behaviour==elevator.EB_DoorOpen {
				elevio.SetDoorOpenLamp(true)
				obstruction = true
			} else {
				obstruction = false
			}
		case stop:= <-drv_stop:
			if stop{
				elevio.SetMotorDirection(elevio.MD_Stop)
			}

	// if timer.TimerTimedOut() {
	// 	timer.TimerStop()
	// 	e = fsm.Fsm_onDoorTimeout(e)
	// }
		// }
		// fmt.Printf("timer stopped?: %v\n",timer.TimerTimedOut())
		fmt.Printf("----------------END\n")
		fmt.Printf("\n")
		time.Sleep(time.Duration(config.InputPollRate))

	}
	// for{
	// 	for f := 0; f < config.NumFloors; f++{
	// 		for b := 0; b < config.NumButtons; b++{
	// 			v := e.Requests[f][b]
	// 			if(v  &&  v != prevRequestButton [f][b]){
	// 				fsm.Fsm_onRequestButtonPress(e,f,elevio.ButtonType(b))				}
	// 			prevRequestButton [f][b] = v;
	// 		}
	// 	}
	// }
}

// Start elevator FSM and handle initial conditions
// go func() {
// 	for {
// 		e.Floor = elevio.GetFloor()
// 		fmt.Printf("%v\n",e.Floor)

// 		select {
//         // case button := <-drv_buttons:
//         //     fmt.Printf("I have a call at %v \n", button)
//         //     elevio.SetButtonLamp(button.Button,button.Floor,true)
//         //     fsm.Fsm_onRequestButtonPress(e, button.Floor, button.Button)
//         //     prevRequestButton[button.Floor][button.Button] = true
// 		// 	for f := 0; f < config.NumFloors; f++{
// 		// 		fmt.Printf("%v\n",e.Requests[f][0])
// 		// 		fmt.Printf("%v\n",e.Requests[f][1])
// 		// 		fmt.Printf("%v\n",e.Requests[f][2])
// 		// 	}

// 		case floor := <-drv_floors:
// 			if(floor != -1  &&  floor != prevFloorSensor){
// 				fsm.Fsm_onFloorArrival(e,floor)

// 			}
// 			if(floor == config.NumFloors-1) {
// 				elevio.SetMotorDirection(elevio.MD_Stop)
// 			} else if(floor == 0) {
// 				elevio.SetMotorDirection(elevio.MD_Stop)
// 			}
// 			prevFloorSensor = floor;
// 		case obstruction := <-drv_obstr:
// 			if obstruction {
// 				// Håndter obstruksjon hvis nødvendig
// 				elevio.SetDoorOpenLamp(true)
// 			}
// 		case stop := <-drv_stop:
// 			if stop {
// 				// Håndter stoppknapp
//                 elevio.SetMotorDirection(elevio.MD_Stop)
// 			}
// 		}
// 	}
// }()

// for {
// 	// Behandling av gulvsensor
// 	f := elevio.GetFloor()
// 	if f != -1 && f != prevFloorSensor {
// 		fsm.Fsm_onFloorArrival(e, f)
// 	}
// 	prevFloorSensor = f

// 	// Behandling av timer
// 	if timer.TimerTimedOut() {
// 		timer.TimerStop()
// 		fsm.Fsm_onDoorTimeout(e)
// 	}

// 	// Søvntilstand for å imitere polling
// 	time.Sleep(time.Millisecond * time.Duration(config.InputPollRate))
// }
}