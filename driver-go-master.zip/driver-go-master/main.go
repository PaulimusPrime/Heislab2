package main

import (
	// "Driver-go/config"
	"Driver-go/config"
	"Driver-go/elevator"
	"Driver-go/elevio"
	"Driver-go/fsm"

	// "Driver-go/fsm"
	//"Driver-go/requests"
	// "Driver-go/timer"
	// "fmt"
	// "time"
)

func main() {

	elevio.Init("localhost:15657", config.NumFloors)

	var (
		e                 elevator.Elevator
		//prevRequestButton [config.NumFloors][config.NumButtons]bool
		//prevFloorSensor   = -1
	)

    //initializing elevator correctly
    e.Behaviour=elevator.EB_Idle
    e.Floor=elevio.GetFloor()
    e.Dirn=elevio.MD_Stop
    for f := 0; f < config.NumFloors; f++ {
        for b := 0; b < config.NumButtons; b++{
            e.Requests[f][b]=false
        }
        
    }

	drv_buttons := make(chan elevio.ButtonEvent)
	drv_floors := make(chan int)
	drv_obstr := make(chan bool)
	drv_stop := make(chan bool)

	go elevio.PollButtons(drv_buttons)
	go elevio.PollFloorSensor(drv_floors)
	go elevio.PollObstructionSwitch(drv_obstr)
	go elevio.PollStopButton(drv_stop)

    
    for {
        select{
        case button := <-drv_buttons:
            e.Requests[button.Floor][button.Button]=true
            fsm.Fsm_onRequestButtonPress(e,button.Floor,button.Button)
        case floor := <-
        }
    }



	// Start elevator FSM and handle initial conditions
	// go func() {
	// 	for {
	// 		select {
	// 		case floor := <-drv_floors:
	// 			if floor == -1 {
	// 				fmt.Printf("Elevator initialized between floors %+v\n", floor)
	// 				fsm.Fsm_onInitBetweenFloors(e)
	// 			}
    //         case button := <-drv_buttons:
    //                 add e.requests[floor][button]=true
    //             fmt.Printf("I have a call at %v \n", button)
    //             elevio.SetButtonLamp(button.Button,button.Floor,true)
    //             fsm.Fsm_onRequestButtonPress(e, button.Floor, button.Button)
    //             prevRequestButton[button.Floor][button.Button] = true
	// 		case obstruction := <-drv_obstr:
	// 			if obstruction {
	// 				// Håndter obstruksjon hvis nødvendig
	// 				elevio.SetDoorOpenLamp(true)
	// 			}
	// 		case stop := <-drv_stop:
	// 			if stop {
	// 				// Håndter stoppknapp
    //                 elevio.SetMotorDirection(elevio.MD_Stop)
	// 			}
	// 		}
	// 	}
	// }()

	// for {
	// 	// Behandling av gulvsensor
	// 	f := elevio.GetFloor()
	// 	if f != -1 && f != prevFloorSensor {
	// 		fsm.Fsm_onFloorArrival(e, f)
	// 	}
	// 	prevFloorSensor = f

	// 	// Behandling av timer
	// 	if timer.TimerTimedOut() {
	// 		timer.TimerStop()
	// 		fsm.Fsm_onDoorTimeout(e)
	// 	}

	// 	// Søvntilstand for å imitere polling
	// 	time.Sleep(time.Millisecond * time.Duration(config.InputPollRate))
	// }
}

    // elevio.Init("localhost:15657", config.NumFloors)

    // var (
    //     e elevator.Elevator
    //     prevRequestButton [config.NumFloors][config.NumButtons]bool
    //     prevFloorSensor   = -1
    // )
    
    // drv_buttons := make(chan elevio.ButtonEvent)
    // drv_floors  := make(chan int)
    // drv_obstr   := make(chan bool)
    // drv_stop    := make(chan bool)    
    
    // go elevio.PollButtons(drv_buttons)
    // go elevio.PollFloorSensor(drv_floors)
    // go elevio.PollObstructionSwitch(drv_obstr)
    // go elevio.PollStopButton(drv_stop)

    // if a := <-drv_floors;a== -1{
    //     fmt.Printf("Elevator initialized between floors %+v\n", a)
    //     fsm.Fsm_onInitBetweenFloors(e)
    // }

    // for {
    //     // Behandling av knappetrykk
	// 	for f := 0; f < config.NumFloors; f++ {
	// 		for b := 0; b < config.NumButtons; b++{
    //             var v = e.Requests[f][b]
	// 			if v != prevRequestButton[f][b] && v {
	// 				fsm.Fsm_onRequestButtonPress(e,f,elevio.ButtonType(b))
	// 			}
	// 			prevRequestButton[f][b] = v
	// 		}
	// 	}

    //     f := elevio.GetFloor()
    //     if f!=-1 && f!=prevFloorSensor{
    //         fsm.Fsm_onFloorArrival(e,f)
    //     }
    //     prevFloorSensor = f

    //     if timer.TimerTimedOut(){
    //         timer.TimerStop()
    //         fsm.Fsm_onDoorTimeout(e)
    //     }
    //     time.Sleep(time.Millisecond*time.Duration(config.InputPollRate))
    // }