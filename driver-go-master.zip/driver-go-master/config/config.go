package config

import "time"

const(
NumFloors int = 4
NumButtons int =3
DoorOpenDurationS = 3
InputPollRate = 20 * time.Millisecond
)
