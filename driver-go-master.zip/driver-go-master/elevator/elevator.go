package elevator

import (
	//"fmt"
	"Driver-go/elevio"
	"Driver-go/config"
)

//Elevatorbehavior gives information about the state that the elevator is in.
type ElevatorBehaviour int
const (
	EB_Idle   ElevatorBehaviour = 0
	EB_DoorOpen                 = 1
	EB_Moving                   = 2
)

//Everyone waiting or only those that want to travel in that direction goes on
// type ClearRequestVariant int
// const(
// 	CV_all ClearRequestVariant = iota
// 	CV_InDirn
// )

type Elevator struct{
	Floor int
	Dirn elevio.MotorDirection
	Requests[config.NumFloors][config.NumButtons] bool
	Behaviour ElevatorBehaviour
}